const fs = require('fs');

// post = {
//     id: 3123,
//     title: 'Salom abdushujkur',
//     content: 'dasd ada asdlorems ewrwererwerwe'
// }

// CRUD - Create / Read / Update / Delete
module.exports = {

    update: function (modifiedPost) {
        let postsFromFile = this.getAll();
        let foundIndex = postsFromFile.findIndex((post) => post.id === modifiedPost.id);
        postsFromFile[foundIndex] = modifiedPost;
        this.save(postsFromFile);
    },

    remove: function (postID) {
        let posts = this.getAll();
        let postsFiltered = posts.filter((post)=> post.id != postID);
        this.save(postsFiltered);
    },

    add: function (post) {
        let postsFromFile = this.getAll();
        postsFromFile.push(post);
        this.save(postsFromFile);
    },

    save: function(posts) {
        let postsAsText = JSON.stringify(posts);
        fs.writeFileSync('./data.json', postsAsText);
    },

    getAll: function () {
        let postsAsText = fs.readFileSync('./data.json');
        return JSON.parse(postsAsText);
    }
    // getAll()    [{}, {}, {}]
}